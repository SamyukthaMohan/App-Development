import React from 'react';
import PodcastEpisode from './PodcastEpisode'; 
import './Dashboard.css'; 


const episodes = [
  {
    id: 1,
    title: 'The Adventure Begins',
    description: 'Join us on a magical journey through the enchanted forest.',
    audioUrl: 'audio/episode1.mp3',
    imageUrl: 'images/episode1.jpg',
  },
  {
    id: 2,
    title: 'The Lost Treasure',
    description: 'Captain Jack and his crew search for buried treasure.',
    audioUrl: 'audio/episode2.mp3',
    imageUrl: 'images/episode2.jpg',
  },
  {
    id: 3,
    title: 'The Secret Garden',
    description: 'Discover the hidden wonders of the secret garden.',
    audioUrl: 'audio/episode3.mp3', 
    imageUrl: 'images/episode3.jpg', 
  },
  
];

function DashboardPage() {
  return (
    <div>
      
      <div className="dashboard">
      <h1>Kids Storytelling Podcast</h1>
      <div className="episode-list">
        {episodes.map((episode) => (
          <PodcastEpisode key={episode.id} episode={episode} />
        ))}
      </div>
    </div>
    </div>
  );
}

export default DashboardPage;