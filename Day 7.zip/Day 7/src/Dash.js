import React from 'react'
import './Dash.css'
import DashboardPage from './DashboardPage';
import LogoutIcon from '@mui/icons-material/Logout';
import GridViewIcon from '@mui/icons-material/GridView';
import NotificationsNoneOutlinedIcon from '@mui/icons-material/NotificationsNoneOutlined';
import AccountCircleOutlinedIcon from '@mui/icons-material/AccountCircleOutlined';
// import SearchIcon from '@mui/icons-material/Search';
import SettingsIcon from '@mui/icons-material/Settings';
import LanguageIcon from '@mui/icons-material/Language';
import FeedbackIcon from '@mui/icons-material/Feedback';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { selectUser } from './Redux/UserSlice';


function Dash() {

  const user = useSelector(selectUser);
  const dispatch = useDispatch();

  // Check if user is not null before accessing its properties
  const email = user ? user.email:"Guest";
  return (
    <div>
    <DashboardPage/>
    <div className='body'>
    <div className='mainnavigation'>
   
    <h2 className='maindb'><GridViewIcon className='dbicon'/>Dashboard</h2>
    <h1 className='mainlag'><LanguageIcon className='lagcon'/>Languages</h1>
    <h1 className='mainfed'><FeedbackIcon className='fedcon'/>FeedBack</h1>
    <h1 className='mainset'><SettingsIcon className='setcon'/>Settings</h1>
    <Link to="/"> <h1 className='mainlog'><LogoutIcon className='logicon'/>Logout</h1></Link>
    <h2 className='wel'>Welcome {email} </h2>
    <div className='secnav'></div>
    <nav className="navbar">
      <ul className="nav-list">
        <li className="nav-item"><a href="#">Home</a></li>
        <li className="nav-item"><a href="#">Language</a></li>
        <li className="nav-item"><a href="#">Reports</a></li>
        <li className="nav-item"><a href="#">Analytics</a></li>
        <li className="nav-item"><a href="#">Search</a></li>
      </ul>
    </nav>
    
    <div className="search-container">
      
     <NotificationsNoneOutlinedIcon className='noti'/>
     <AccountCircleOutlinedIcon className='person'/>
  </div>

  </div>
  </div>
  </div>
  
  
  )
}

//<img className='kids' src='https://media.istockphoto.com/id/1248963146/vector/thirsty-crow.jpg?s=612x612&w=0&k=20&c=DNtPuu28A-I16KC-vTYicg-m8d7Wm7OaLCOUPcsNr4k='></img>
export default Dash