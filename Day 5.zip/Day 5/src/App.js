import React from 'react';
import {BrowserRouter, Route, Routes} from 'react-router-dom';
import Login from './Login';
import Register from './Register';
import './App.css';
import Dash from './Dash';
import DashboardPage from './DashboardPage';
import AdminLogin from './AdminLogin';
import AdminDash from './AdminDash';

function App() {
  return (
    <div className="App">
    <BrowserRouter>
    <Routes>
    <Route path='/' element={<Login/>}></Route>
    <Route path='/register' element={<Register/>}></Route>

     <Route path='/dash' element={<Dash/>}></Route>
     <Route path='/admin' element={<AdminLogin/>}></Route>
     <Route path='/addash' element={<AdminDash/>}></Route>
      </Routes>
    </BrowserRouter>
    </div>
  );
}

export default App;
