import React from 'react'
import './AdminDash.css'
//import DashboardPage from './DashboardPage';
import LogoutIcon from '@mui/icons-material/Logout';
import GridViewIcon from '@mui/icons-material/GridView';
import NotificationsNoneOutlinedIcon from '@mui/icons-material/NotificationsNoneOutlined';
import AccountCircleOutlinedIcon from '@mui/icons-material/AccountCircleOutlined';
// import SearchIcon from '@mui/icons-material/Search';
import SettingsIcon from '@mui/icons-material/Settings';
import LanguageIcon from '@mui/icons-material/Language';
import FeedbackIcon from '@mui/icons-material/Feedback';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { selectUser } from './Redux/UserSlice';
import { Button } from '@mui/material';


function AdminDash() {

  const user = useSelector(selectUser);
  const dispatch = useDispatch();

  // Check if user is not null before accessing its properties
  const email = user ? user.email:"Guest";
  return (
    <div>
    <div className='addbody'>
    <div className='addmainnavigation'>
   
    <h2 className='addmaindb'><GridViewIcon className='dbicon'/>Dashboard</h2>
    <h1 className='addmainlag'><LanguageIcon className='lagcon'/>Uploaded</h1>
    <h1 className='addmainfed'><FeedbackIcon className='fedcon'/>FeedBack</h1>
    <h1 className='addmainset'><SettingsIcon className='setcon'/>Settings</h1>
    <Link to="/admin"> <h1 className='addmainlog'><LogoutIcon className='addlogicon'/>Logout</h1></Link>
    <h3 className='addwel'>Welcome {email} </h3>
    <div className='addsecnav'></div>
    <nav className="addnavbar">
      <ul className="addnav-list">
        <li className="addnav-item"><a href="#">Home</a></li>
        <li className="addnav-item"><a href="#">Language</a></li>
        <li className="addnav-item"><a href="#">Reports</a></li>
        <li className="addnav-item"><a href="#">Analytics</a></li>
        <li className="addnav-item"><a href="#">Search</a></li>
      </ul>
    </nav>
    <img className='story1' src='https://c4.wallpaperflare.com/wallpaper/571/820/36/5bd345e710ae6-wallpaper-preview.jpg'></img>
    <button className='addupload'>Upload</button>
    <button className='adddelete'>Delete</button>
    <div className="addsearch-container">
      
     <NotificationsNoneOutlinedIcon className='addnoti'/>
     <AccountCircleOutlinedIcon className='addperson'/>
  </div>

  </div>
  </div>
  </div>
  
  
  )
}

//<img className='kids' src='https://media.istockphoto.com/id/1248963146/vector/thirsty-crow.jpg?s=612x612&w=0&k=20&c=DNtPuu28A-I16KC-vTYicg-m8d7Wm7OaLCOUPcsNr4k='></img>
// <DashboardPage/>
export default AdminDash